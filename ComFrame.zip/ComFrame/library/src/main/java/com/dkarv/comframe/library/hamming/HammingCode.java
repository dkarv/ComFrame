package com.dkarv.comframe.library.hamming;

public enum HammingCode {
    NO, HAMMING_7_4, HAMMING_15_11
}
